#include "ponto.h"

typedef struct reta{
    Ponto p1, p2;
    float tamanho;
}Reta;

float calcula_tamanho(Reta r);
