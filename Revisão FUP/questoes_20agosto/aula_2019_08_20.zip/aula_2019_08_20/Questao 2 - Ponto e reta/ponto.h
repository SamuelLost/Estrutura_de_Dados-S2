
typedef struct ponto{
    int x;
    int y;
}Ponto;

