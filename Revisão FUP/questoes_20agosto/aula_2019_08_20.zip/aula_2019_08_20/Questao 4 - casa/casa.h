typedef struct casa{
    float area;
    int qtd_quartos;
    int qtd_portas;
    char cor[20];
}Casa;
