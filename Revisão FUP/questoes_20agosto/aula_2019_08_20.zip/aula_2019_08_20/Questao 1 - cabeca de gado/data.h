
typedef struct data{
    int mes;
    int ano;
}Data;

