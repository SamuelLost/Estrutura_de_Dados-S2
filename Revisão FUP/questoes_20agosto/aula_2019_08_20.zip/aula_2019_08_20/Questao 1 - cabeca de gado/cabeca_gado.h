#include "data.h"

typedef struct cabeca_de_gado{
    int codigo;
    float leite;
    float alim;
    Data nasc;
    char abate;
}Cabeca_de_gado;
