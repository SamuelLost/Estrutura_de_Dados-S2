struct paciente{
    char nome[50];
    char endereco[50];
    char telefone[8];
    float altura;
    char data_nasc[8];
    float peso;
};

typedef struct paciente Paciente;
