struct pessoa{
    char nome[50];
    char endereco[50];
    char telefone[8];
};

typedef struct pessoa Pessoa;
